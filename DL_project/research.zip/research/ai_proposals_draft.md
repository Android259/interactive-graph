# AI Proposals Draft

Staging registry produced by the architecture research pass. Entries are ready
for later review and transfer into `research/proposals.md`; this file does not
change proposal status in the shared registry.

## Verified Project Context

- The default configuration uses a two-layer residual GATv2 protein encoder,
  projected ESM3 residue embeddings, buriedness, global max pooling, and a
  binary MLP classifier. Attention, GRAB, and chemical lipid graphs are gated
  options.
- The full CSV has 11,018 pairs: 756 positive and 10,262 zero-labelled pairs,
  35 proteins, and 312 lipid identities.
- With the seed-0 default sampling procedure, 1,334 pairs are retained and
  split into 1,134 train, 100 validation, and 100 test rows.
- In that random split, all 28 validation proteins and 83 of 84 validation
  lipid identities also occur in train. All 31 test proteins and 85 of 87 test
  lipid identities also occur in train.
- Nine historical metric rows are available, but all lack a complete
  configuration snapshot and completed run summary. Eight have constant test
  predictions, so they cannot support architecture ranking.

#### AI-PROP-20260607-001: Enforce batch-isolated lipid attention

- Status: proposed
- Priority: high
- Project observation: In fragment-mask mode, `mult_mask & attn_mask` evaluates to an all-false mask for normally batched fragments, so lipid self-attention can mix atoms from different samples. The single-attention path also computes the first lipid encoder twice; without stochastic layers the second call repeats computation.
- Proposed change: Correct the fragment mask so attention is restricted to the intended sample and fragment relation, add co-batching invariance tests, and remove the duplicate deterministic lipid-encoder call after equivalence is demonstrated.
- Mechanism or rationale: A prediction for one pair must not depend on which unrelated pairs share its batch. Correct masking restores sample independence; eliminating the duplicate call reduces cost without changing the function.
- Supporting sources: AI-PAPER-20260607-001; AI-PAPER-20260607-003.
- Required implementation: Define the permitted attention relation explicitly, convert it to PyTorch's blocked-position mask, test one sample alone versus co-batched with unrelated samples, and count lipid-encoder forward calls.
- Control and ablation: Compare corrected self-attention against self-attention disabled. Do not treat the cross-sample implementation as a scientifically valid baseline.
- Validation metric: Maximum absolute co-batching logit difference, validation balanced accuracy, validation AUPRC, and runtime per batch.
- Failure criterion: Co-batching changes a sample's logits above numerical tolerance, or corrected self-attention fails to outperform the no-self-attention control across repeated seeds.
- Expected compute cost: Low for tests and correction; corrected masking keeps the same asymptotic attention cost, while removing the duplicate call lowers lipid-encoder compute.
- Confounders: Random fragment choice must be fixed during invariance tests; dropout or other stochastic layers would require controlled RNG.
- Evidence strength: established for the code-level isolation failure; supported for the fragment aggregation principle.
- Added: 2026-06-07

#### AI-PROP-20260607-002: Separate inductive and transductive GRAB evaluation

- Status: proposed
- Priority: high
- Project observation: GRAB coefficients for train targets are built from source labels in `full_csv`, including sources outside the train split. Those sources can therefore expose validation or test labels during optimization.
- Proposed change: Add an evaluation-only experimental variant in which GRAB source coefficients use train-labelled sources exclusively. Report the existing version explicitly as transductive and the restricted version as leakage-safe inductive training.
- Mechanism or rationale: Holdout labels must not influence fitted parameters when the claimed target is generalization to unseen pairs or entities. Comparing both variants measures how much performance comes from transductive label propagation.
- Supporting sources: AI-PAPER-20260607-004.
- Required implementation: Build coefficients with non-train source labels masked, retain the same target top-k graph, record usable-neighbor counts per target, and preserve the existing implementation as the transductive control.
- Control and ablation: Cross-entropy without GRAB; current transductive GRAB; train-source-only GRAB. Evaluate all three under identical splits and seeds.
- Validation metric: Validation balanced accuracy, AUPRC, MCC, and performance stratified by targets with 0, 1-5, 6-19, or 20 usable train neighbours.
- Failure criterion: Train-source-only GRAB does not improve over cross-entropy, or gains occur only in the transductive condition.
- Expected compute cost: Low; graph coefficients remain precomputed and batch-time complexity is unchanged.
- Confounders: Removing holdout labels reduces neighbour coverage, so coverage-stratified reporting is required; random and cold splits answer different questions.
- Evidence strength: established leakage path from code; expected quality effect requires experiment.
- Added: 2026-06-07

#### AI-PROP-20260607-003: Establish warm-start and cold-start evaluation protocols

- Status: proposed
- Priority: high
- Project observation: The default random pair split has near-complete protein and lipid identity overlap with train, so it measures interpolation between known entities rather than generalization to new proteins or lipids.
- Proposed change: Evaluate four fixed protocols: random pair warm-start, cold protein, cold lipid, and double-cold protein-plus-lipid. Keep validation and test selection entity-disjoint for the corresponding protocol.
- Mechanism or rationale: Pairwise interaction prediction has distinct deployment settings. Entity-disjoint splits prevent repeated protein or lipid identity from serving as a shortcut when measuring inductive generalization.
- Supporting sources: AI-PAPER-20260607-002; AI-PAPER-20260607-004; AI-PAPER-20260607-005.
- Required implementation: Generate deterministic split manifests, record entity and chemical-similarity overlap, fit all sampling and weighting operations using train only, and aggregate repeated seeds without selecting on test.
- Control and ablation: Run the same frozen configuration on all four protocols; include protein-ID frequency and lipid-ID frequency baselines.
- Validation metric: Balanced accuracy, AUPRC, MCC, sensitivity, specificity, and per-protein results; report mean and standard deviation across at least three seeds.
- Failure criterion: The model does not exceed entity-frequency and class-prior baselines, or performance collapses to chance on the intended deployment protocol.
- Expected compute cost: Medium because each configuration is repeated across protocols and seeds; no architecture expansion is required.
- Confounders: Only 35 proteins are available, making cold-protein estimates high variance; protein-family exclusions and exact protein exclusions must not be mixed in one aggregate.
- Evidence strength: established evaluation concern; protocol-specific model quality requires experiment.
- Added: 2026-06-07

#### AI-PROP-20260607-004: Build a representation baseline ladder before increasing model capacity

- Status: proposed
- Priority: high
- Project observation: The sampled default train set has about 1,134 pairs while the historical model has about 2.85 million parameters. Existing metrics cannot show that GATv2, cross-attention, or chemical graph encoding beats simpler representations.
- Proposed change: Compare class-prior and entity-frequency controls, ECFP plus pooled ESM embeddings with a small MLP, a directed-bond MPNN/GINE lipid encoder, and the current GATv2 model.
- Mechanism or rationale: On small molecular datasets, fixed fingerprints can be competitive; a baseline ladder identifies whether gains arise from chemical message passing, protein structure, or model capacity.
- Supporting sources: AI-PAPER-20260607-001; AI-PAPER-20260607-002.
- Required implementation: Use the same split manifests, class/sample weights, stopping rule, parameter-count report, and seed set. Tune each family within a small matched budget.
- Control and ablation: Lipid-only, protein-only, concatenated fixed representations, graph encoders without cross-attention, and the full model.
- Validation metric: Validation balanced accuracy and AUPRC as primary metrics; parameter count, wall time, and peak memory as efficiency metrics.
- Failure criterion: The full model does not consistently exceed the best simple baseline by a predeclared practical margin across seeds and the intended cold split.
- Expected compute cost: Medium; simple baselines are cheap and can eliminate low-value large-model searches.
- Confounders: Fingerprint radius and ESM pooling are hyperparameters; fair comparison requires comparable tuning effort and no test-based selection.
- Evidence strength: supported by molecular representation literature and current sample-to-parameter scale.
- Added: 2026-06-07

#### AI-PROP-20260607-005: Audit zero labels and test a PU-compatible objective

- Status: proposed
- Priority: high
- Project observation: The table contains 10,262 zero-labelled versus 756 positive pairs, but the inspected artifacts do not establish whether every zero is an experimentally verified non-interaction. Training currently treats sampled zeros as negatives; a historical PU loss remains commented.
- Proposed change: Classify zero-label provenance. If zeros are unlabeled rather than verified negatives, compare weighted cross-entropy with non-negative PU learning and with a high-confidence-negative subset.
- Mechanism or rationale: Treating unknown interactions as true negatives introduces false-negative noise. PU learning addresses positive-plus-unlabeled supervision, while credible-negative filtering tests sensitivity to label construction.
- Supporting sources: AI-PAPER-20260607-005; AI-PAPER-20260607-006.
- Required implementation: Produce a provenance table, estimate or bound the positive class prior using train data only, implement nnPU as an optional objective, and keep the active cross-entropy path as control.
- Control and ablation: Cross-entropy on current zeros; cross-entropy on credible negatives; nnPU on positives plus unlabeled pairs. Use identical representations and splits.
- Validation metric: AUPRC, balanced accuracy, precision at fixed recall, calibration, and performance on any independently verified negative subset.
- Failure criterion: Zero labels are confirmed true negatives, the class prior cannot be justified, or nnPU fails to improve validation robustness across priors and seeds.
- Expected compute cost: Low to medium; objective computation is cheap, but provenance work may be substantial.
- Confounders: PU assumptions can fail under selection bias; tuning the class prior on test data would invalidate the comparison.
- Evidence strength: established conditional method; applicability depends on unresolved label provenance.
- Added: 2026-06-07

#### AI-PROP-20260607-006: Add hierarchical fragment-to-lipid aggregation

- Status: proposed
- Priority: medium
- Project observation: In graph concat and fragment-mask modes, disconnected fragment atoms are ultimately pooled directly into one lipid vector. Fragment identity is not represented in the final pooling hierarchy.
- Proposed change: Pool atoms within each fragment, transform fragment vectors with a shared network, then aggregate the fragment set into a lipid vector using a permutation-invariant operator.
- Mechanism or rationale: Two-stage aggregation preserves component boundaries while remaining invariant to fragment order and avoids making lipid size the only route by which fragment count affects the pooled vector.
- Supporting sources: AI-PAPER-20260607-003.
- Required implementation: Reuse `lipid_batch` for atom-to-fragment pooling and PyG `batch` for fragment-to-lipid pooling; test sum, mean, and learned Deep Sets aggregation with matched hidden size.
- Control and ablation: Current atom-level pooling; hierarchical pooling without inter-fragment attention; hierarchical pooling with fragment-level attention only if the simpler variant helps.
- Validation metric: Validation balanced accuracy and AUPRC by fragment count, plus permutation-invariance and empty/single-fragment tests.
- Failure criterion: No consistent gain for multi-fragment lipids, degradation on single-fragment lipids, or sensitivity to fragment ordering.
- Expected compute cost: Low; fragment counts are small and aggregation occurs after atom encoding.
- Confounders: Some semicolon-separated entries may be alternatives rather than simultaneous molecular components; biochemical interpretation must be audited before combining them.
- Evidence strength: supported architectural principle; project-specific benefit is speculative.
- Added: 2026-06-07

#### AI-PROP-20260607-007: Introduce a minimal training-stability protocol

- Status: proposed
- Priority: medium
- Project observation: Eight of nine historical test reports contain constant predictions, but their configurations and complete validation histories are missing. The active optimizer has no weight decay, scheduler, or dropout, and the default run is one epoch.
- Proposed change: Before broad architecture search, run a compact stability matrix over seed, learning rate, Adam versus AdamW, and modest dropout, with validation-based early stopping and complete configuration snapshots.
- Mechanism or rationale: Repeated-seed stability checks separate optimization collapse from representational failure and prevent architecture conclusions from single unstable runs.
- Supporting sources: AI-PAPER-20260607-002.
- Required implementation: Use one fixed split manifest per seed, log prediction class counts and finite gradients each epoch, save validation summaries, and select checkpoints by validation balanced accuracy.
- Control and ablation: Current Adam setup; AdamW with fixed weight decay; dropout off versus one modest predeclared value. Keep architecture fixed.
- Validation metric: Mean and standard deviation of validation balanced accuracy and AUPRC, collapse frequency, epochs to best, and best-to-final drop.
- Failure criterion: No setting avoids constant predictions across seeds, or apparent gains disappear after controlling split and seed.
- Expected compute cost: Medium but bounded; the grid should precede expensive architecture ablations.
- Confounders: Historical runs are not comparable because their configuration snapshots are incomplete; test results must not select stability settings.
- Evidence strength: observed collapse signal, but its cause is unresolved.
- Added: 2026-06-07
