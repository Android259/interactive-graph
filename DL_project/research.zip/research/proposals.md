# Research Proposals

This is the shared append-only proposal registry. Preserve proposal IDs and
history. Update status instead of deleting rejected or completed proposals.

## Предложения по части ИИ

### Entry Format

#### AI-PROP-YYYYMMDD-NNN: Short title

- Status: proposed
- Priority:
- Project observation:
- Proposed change:
- Mechanism or rationale:
- Supporting sources:
- Required implementation:
- Control and ablation:
- Validation metric:
- Failure criterion:
- Expected compute cost:
- Confounders:
- Evidence strength:
- Added:

#### AI-PROP-20260607-001: Validate GRAB graph loss against the plain class-weighted loss

- Status: proposed
- Priority: high
- Project observation: `research/project_audit.md` records an active `GRAB_loss` that adds a graph term to target cross-entropy, while `training/new_train.py` also applies class weights and optional Tanimoto/protein-group weights.
- Proposed change: run the same split and seed with `grab_loss=True` versus `grab_loss=False`, keeping every other configuration field fixed.
- Mechanism or rationale: `AI-PAPER-20260607-004` and `AI-PAPER-20260607-005` indicate that pairwise interaction datasets can be biased by repeated entities and that negative construction can materially change measured performance; the graph term tests whether local pair-neighborhood information helps beyond per-row supervision.
- Supporting sources: `AI-PAPER-20260607-004`; `AI-PAPER-20260607-005`; `research/project_audit.md`.
- Required implementation: one CPU-safe training comparison on the recorded split, with identical seed, optimizer, batch size, and stopping rule.
- Control and ablation: control is the active plain cross-entropy branch; ablation is the same run with only the GRAB graph term removed.
- Validation metric: validation balanced accuracy and validation loss; model selection must stay on validation only.
- Failure criterion: if the GRAB branch does not improve validation balanced accuracy or reduces stability across the same seed, keep the simpler loss.
- Expected compute cost: one additional training run of the existing configuration on the recorded split.
- Confounders: seed variance, class imbalance, and overlap between Tanimoto/common weights and the pair-graph signal.
- Evidence strength: medium.
- Added: 2026-06-07

#### AI-PROP-20260607-002: Compare the lipid-isomer graph path with the legacy 768-d lipid embedding path

- Status: proposed
- Priority: medium
- Project observation: `research/project_audit.md` shows two active lipid paths: a legacy `Linear(768, hiddim)` path and a graph-lipid path with explicit atom/bond features plus optional fragment masking.
- Proposed change: evaluate the same split and seed with `lipid_isomers=False` versus `lipid_isomers=True`, keeping the rest of the model fixed.
- Mechanism or rationale: `AI-PAPER-20260607-002`, `AI-PAPER-20260607-003`, and `BIO-PAPER-20260607-007` support the idea that chemically structured representations and explicit resolution of lipid identity can matter more than coarse one-vector embeddings.
- Supporting sources: `AI-PAPER-20260607-002`; `AI-PAPER-20260607-003`; `BIO-PAPER-20260607-007`; `research/project_audit.md`.
- Required implementation: one pair of CPU-verifiable runs using the same seed, split, and optimizer settings, with the same validation selection rule.
- Control and ablation: control is the legacy 768-d embedding path; ablation is the graph-lipid path with only the representation switched.
- Validation metric: validation balanced accuracy, F1, and loss; selection must use validation only.
- Failure criterion: if the graph path is not consistently better or increases instability, keep the legacy path for this dataset.
- Expected compute cost: one additional training run plus the one-time lipid graph lookup already present in the code path.
- Confounders: missing lipid isomer coverage, fragment handling, and the fact that the graph path changes both representation granularity and encoder depth.
- Evidence strength: medium.
- Added: 2026-06-07

## Предложения по биохимии

### Entry Format

#### BIO-PROP-YYYYMMDD-NNN: Short title

- Status: proposed
- Priority:
- Project observation:
- Biochemical proposal:
- Mechanism or rationale:
- Supporting sources:
- Required data or audit:
- Control and ablation:
- Validation metric:
- Falsification criterion:
- Confounders:
- Evidence strength:
- Added:

#### BIO-PROP-20260607-001: Audit lipid resolution before treating fragment or isomer strings as interchangeable

- Status: proposed
- Priority: high
- Project observation: `research/project_audit.md` records that the current data pipeline canonicalizes SMILES and can switch between global, fragment, and isomer graph modes, while `data/AGENTS.md` warns that lipid identity resolution must stay synchronized with graph construction.
- Biochemical proposal: audit whether the same nominal lipid label in the CSV maps to multiple chemically distinct canonical SMILES and whether those distinctions align with the stored graph index.
- Mechanism or rationale: `BIO-PAPER-20260607-007` shows that lipid annotations have distinct resolution levels, and `BIO-PAPER-20260607-002` / `BIO-PAPER-20260607-003` show that chain- and stereo-level changes can alter binding-relevant structure.
- Supporting sources: `BIO-PAPER-20260607-002`; `BIO-PAPER-20260607-003`; `BIO-PAPER-20260607-007`; `research/project_audit.md`.
- Required data or audit: inspect the processed CSV, canonical SMILES lists, and `data/lipid_graphs/lipid_graph_index.csv` for one-to-many label-to-structure mappings.
- Control and ablation: compare coarse label grouping against canonical-SMILES grouping; keep the same dataset rows and only change the identity resolution used in the audit.
- Validation metric: duplicate-label rate, unique canonical-SMILES count per lipid label, and count of rows whose structural resolution is ambiguous.
- Falsification criterion: if each label resolves to a unique canonical SMILES under the active pipeline, then the ambiguity concern is not supported for this dataset snapshot.
- Confounders: normalization choices, fragment fallback behavior, and SMILES strings with missing or non-canonical components.
- Evidence strength: medium.
- Added: 2026-06-07
