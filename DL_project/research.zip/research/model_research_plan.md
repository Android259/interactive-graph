# План Исследования Модели

Ниже — конкретный список конфигураций, которые стоит протектировать для полноценного исследования. Список идет от общего к частному.

## 1. Обязательный baseline

- `seed=0`
- `excluded_groups` пусто
- `excluded_subgroups` пусто
- `grab_loss=False`
- `lipid_isomers=False`
- `lipid_fragments_treatment=0` (`lipid_concat`)
- `lipid_self_attention=True`
- `plmon=True`
- `buryon=True`
- `protein_self_attention=True`
- `cross_attention=True`
- `double_attention=False`
- `third_layers_in_mlps=False`
- `protein_pooling=0` (`ordinary_prot_pooling`)
- `tanimoto_weight=True`
- `protein_group_weight=False`
- `type_opt=False`
- `loss_type=1`
- `pool_type=1`
- `HEADS=8`
- `hiddim=128`
- `m=4`
- `lr=0.001`
- `batch=16`
- `ep=1`
- `num_workers=4`

## 2. Split and data configurations

- `seed=1`, `seed=2`, `seed=3` для повторов baseline
- `excluded_groups=...` по одному домену за раз
- `excluded_subgroups=...` по одному семейству за раз
- `grab_loss=True` против `grab_loss=False`
- тот же CSV snapshot без изменений

## 3. Lipid configurations

- `lipid_isomers=False` vs `lipid_isomers=True`
- `lipid_fragments_treatment=0` (`lipid_concat`)
- `lipid_fragments_treatment=1` (`lipid_random_choice`)
- `lipid_fragments_treatment=2` (`lipid_fragments_mask`)
- `lipid_self_attention=True` в baseline
- `lipid_self_attention=False` проверяется один раз как sanity-check
- при `lipid_fragments_treatment=2` обязательно сохранять `lipid_batch`

## 4. Protein configurations

- `plmon=True` vs `plmon=False`
- `buryon=True` vs `buryon=False`
- `protein_self_attention=True` в baseline
- `protein_self_attention=False` проверяется один раз как sanity-check
- `protein_pooling=0` (`ordinary_prot_pooling`)
- `protein_pooling=1` (`prot_attention_pos_bias`)
- `protein_pooling=2` (`prot_pooling_by_pockets`)

## 5. Architecture configurations

- `cross_attention=True` в baseline
- `cross_attention=False` проверяется один раз как sanity-check
- `double_attention=False` vs `double_attention=True`
- `third_layers_in_mlps=False` vs `third_layers_in_mlps=True`
- `HEADS=4`, `HEADS=8`, `HEADS=12` при фиксированном остальном
- `hiddim=64`, `hiddim=128`, `hiddim=256` при фиксированном остальном
- `m=2`, `m=4`, `m=6` при фиксированном остальном
- `pool_type=0`, `pool_type=1`, `pool_type=2`

## 6. Loss and weighting configurations

- `grab_loss=False` vs `grab_loss=True`
- `tanimoto_weight=False` vs `tanimoto_weight=True`
- `protein_group_weight=False` vs `protein_group_weight=True`
- `loss_type=1` как baseline classification loss
- `loss_type=0`, `loss_type=2` только если нужно проверить regression/BCE branches
- `class_weights` включены как в baseline
- `sample_weights` только если активен `grab_loss` или weight-combination branch

## 7. Training protocol configurations

- `lr=0.001`
- `lr=0.0005`
- `lr=0.0001`
- `batch=16`
- `batch=8`
- `batch=32`
- `ep` для baseline selection, затем отдельные long runs только для выбранных кандидатов
- `num_workers=0`, `num_workers=4`
- `type_opt=False`
- `type_opt=True` только на CUDA

## 8. Recommended run order

1. baseline
2. baseline seeds 1/2/3
3. `grab_loss` on/off
4. `lipid_isomers` on/off
5. один sanity-check без `cross_attention`
6. один sanity-check без `protein_self_attention`
7. один sanity-check без `lipid_self_attention`
8. `protein_pooling` sweep
9. `third_layers_in_mlps` on/off
10. `HEADS` sweep
11. `hiddim` sweep
12. `m` sweep
13. `tanimoto_weight` and `protein_group_weight` toggles
14. `excluded_groups` / `excluded_subgroups` audits

## 9. Что обязательно сохранять

- exact command line
- full config snapshot
- dataset snapshot hash or path
- train/valid/test sizes
- train/valid/test label balance
- validation metrics
- test metrics only after selection
- seed
- hardware mode: CPU or GPU
- AMP status
- run status

## 10. Команды Для Sh

Все команды выполнять из корня проекта. Скрипт исполняемый и имеет shebang, поэтому используется `./training/new_train.py`.

```bash
COMMON=(--lipid_concat --plmon --buryon --ordinary_prot_pooling \
      --tanimoto_weight --loss_type=1 --pool_type=1 \
      --HEADS=8 --hiddim=128 --m=4 \
      --lr=0.001 --batch=16 --ep=1 --num_workers=4)

ATTENTION=(--protein_self_attention --lipid_self_attention --cross_attention)

# 1. Baseline: protein SA + lipid SA + CA, без GRAB
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0

# 2. Независимые повторы baseline
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=1
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=2
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=3

# 3. Attention sanity-checks: каждый вариант запускается только один раз
# Без protein SA; lipid SA и CA остаются
./training/new_train.py "${COMMON[@]}" --lipid_self_attention --cross_attention --seed=0

# Без lipid SA; protein SA и CA остаются
./training/new_train.py "${COMMON[@]}" --protein_self_attention --cross_attention --seed=0

# Без CA; обе self-attention остаются
./training/new_train.py "${COMMON[@]}" --protein_self_attention --lipid_self_attention --seed=0

# 4. Leave-one-protein-group-out: все 9 допустимых групп
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=CRAL-TRIO
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=START
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=lipocalin
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=GLTP
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=IP_trans
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=LBP_BPI_CETP
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=scp2
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=ML
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_groups=OSBP

# 5. Lipid representation
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --lipid_random_choice
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --lipid_fragments_mask
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --lipid_isomers

# 6. Protein pooling
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --prot_attention_pos_bias
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --prot_pooling_by_pockets

# 7. Interaction architecture
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --double_attention
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --third_layers_in_mlps

# 8. Objective and weighting
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --grab_loss
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --no_tanimoto_weight
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --protein_group_weight
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --grab_loss --protein_group_weight

# 9. Capacity sweeps
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --HEADS=4
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --HEADS=12
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --hiddim=64
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --hiddim=256
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --m=2
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --m=6

# 10. Optimisation sweeps
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --lr=0.0005
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --lr=0.0001
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --batch=8
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --batch=32
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --type_opt
```

### Подгруппы Для `--excluded_subgroups`

```text
CRAL-TRIO: ATCAY, BNIPL, RLBP1, SEC14L2, SEC14L4, SEC14L5, SEC14L6, TTPA, TTPAL
START: STARD10, STARD11, STARD2
lipocalin: CRABP2, FABP1, FABP5, FABP7, LCN1, LCN15, PMP2, RBP1, RBP4, RBP5
GLTP: GLTP, GLTPD1
IP_trans: PITPNA, PITPNB, PITPNC1
LBP_BPI_CETP: BPI, BPIFB2
scp2: HSDL2, SCP2, SCP2D1
ML: GM2A
OSBP: OSBPL5, OSBPL9
```

Пример исключения одной подгруппы:

```bash
./training/new_train.py "${COMMON[@]}" "${ATTENTION[@]}" --seed=0 --excluded_subgroups=PITPNA
```
