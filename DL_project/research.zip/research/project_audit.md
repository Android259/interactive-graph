# Project Audit

Canonical factual snapshot for downstream research agents.

- Status: complete
- Audit date: 2026-06-07
- Source revision: not recorded

## Prediction Target

- Verified: the training target is `Interaction` in `data/Processed_Negative_Interaction_Without_Duplicates.csv`, treated as a two-class label by `training/new_train.py` and `architecture/loss.py`.
- Verified: `training/new_train.py` uses `torch.bincount(train_labels, minlength=2)` and `F.cross_entropy(..., weight=class_weights)` for the target classification loss.
- Observed: the model head in `architecture/final_layer.py` returns `[batch, 2]` logits.

## Active Data Pipeline

- Verified: the active pipeline is `training/new_train.py -> training/read_configuration.py -> dataloader/New_dataloader.py -> architecture/interaction_classification.py -> architecture/protein_encoder.py / architecture/lipid_encoder.py -> architecture/cross_attention.py -> architecture/final_layer.py -> architecture/loss.py`.
- Verified: `data/build_lipid_isomer_graphs.py` generates `data/lipid_graphs/*` consumed by `dataloader/New_dataloader.py` when `lipid_isomers` is enabled.
- Verified: `dataloader/GRAB_graph.py` produces `data/grab_pair_graph_edges.csv`, consumed by `PLIDataset.build_current_pair_graph()` when `grab_loss` is enabled.

## Dataset And Splits

- Verified: `data/Processed_Negative_Interaction_Without_Duplicates.csv` has 11,018 rows and 11 columns; label counts are 756 positives and 10,262 negatives.
- Verified: `data/Processed_Negative_int.csv` has 14,119 rows and 11 columns; label counts are 756 positives and 13,363 negatives.
- Verified: `data/Processed_dataset.csv` is a one-column CSV with the header text `SmileGlobal;SmileFragment;LTPProtein;ProteinDomain;FullIdentityOfLipid;Lipid;Screen;Novel`; it is not parsed as a multi-column table by a default CSV reader.
- Observed: `PLIDataset.__init__` uses the first 760 rows as `csvtrue`, samples 5.6% of the remaining rows as `csvfalse`, concatenates them, then samples 85% of the resulting table for training; validation and test are each half of the remaining rows.
- Verified calculation for `seed=0` on `Processed_Negative_Interaction_Without_Duplicates.csv`: `csvtrue=760`, `csvfalse=574`, `csvtt=1334`, `train=1134`, `valid=100`, `test=100`.
- Verified calculation for `seed=0`: train labels `648/486` (`1/0`), validation labels `50/50`, test labels `58/42`.
- Verified calculation for `seed=0`: train domains are `CRAL-TRIO 278`, `START 263`, `GLTP 190`, `lipocalin 138`, `LBP_BPI_CETP 87`, `IP_trans 78`, `scp2 72`, `ML 15`, `OSBP 13`; validation and test domain counts are recorded in the audit notes from the same reproducible split.
- Observed: `seed` controls both the false-row sampling and the train/valid/test split; split membership is therefore seed-dependent.
- Verified: the dataset contains 35 unique proteins and 284 unique lipids in the active 11,018-row CSV.

## Protein Representation

- Verified: protein graph nodes use three features from `dataloader/New_dataloader.py`: `residue_type`, `residue_sas_area`, and `residue_volume`.
- Verified: protein edge attributes use three features: `distance`, `area`, and `boundary`.
- Verified: when `plmon` is enabled, `Protein_encoder` projects a 1536-dim PLM vector to 10 dims via `torch.nn.Linear(1536, 10)` and concatenates it with the 3 node features.
- Verified: when `buryon` is enabled, a one-dimensional buriedness feature is concatenated.
- Verified: `Protein_encoder` uses two `GATv2Conv` layers with `edge_dim=3`, followed by `LayerNorm`, an optional self-attention block, and MLP projection to `hiddim`.
- Observed: `Protein_encoder` output shape is `[N, hiddim]`.

## Lipid Representation

- Verified: the legacy lipid path in `Lipid_encoder` uses a `Linear(768, hiddim)` projection.
- Verified: the graph-lipid path (`lipid_isomers`) uses node features `atomic_num`, `formal_charge`, `degree`, `hybridization`, `is_aromatic`, `is_in_ring`, `chiral_tag`, `chirality_possible`, `total_num_hs`, `mass`, and `gasteiger_charge`.
- Verified: graph-lipid edge attributes use `bond_type`, `is_conjugated`, `is_in_ring`, `stereo`, `bond_dir`, and `is_aromatic`.
- Verified: when `lipid_fragments_mask` is enabled, fragment membership is tracked by `lipid_batch`.
- Verified: `PLIDataset.lipid_graph_smiles()` canonicalizes SMILES with `isomericSmiles=True` and respects `lipid_concat`, `lipid_random_choice`, and `lipid_fragments_mask`.
- Verified: `data/lipid_graphs/lipid_graph_index.csv` contains 1,320 rows mapping canonical SMILES to graph IDs and source columns.

## Pair Graph And Objectives

- Verified: when `grab_loss` is enabled, `PLIDataset.build_current_pair_graph()` loads `data/grab_pair_graph_edges.csv`, keeps at most 20 neighbors per target pair, and builds a PyG graph over pair IDs.
- Verified: `data/grab_pair_graph_edges.csv` has 432,250 rows with columns `source_pair_id`, `target_pair_id`, and `edge_weight`.
- Observed: edge weights are mostly 1.0 with a maximum of 2.0 in the current file.
- Verified: `PLIDataset.build_current_pair_graph()` stores per-target label coefficients in `pair_graph.label_coefficients_by_target`.
- Verified: `architecture/loss.GRAB_loss()` combines target classification cross-entropy with an optional graph term from `grab_label_coefficients`; if no graph coefficients are present, it reduces to target loss only.
- Verified: `training/new_train.py` forms `class_weights` from the training label counts and optional `common_weights` from Tanimoto and protein-group weights.

## Model Architecture

- Verified: `InteractionClassification` composes two `Lipid_encoder` instances, two `Protein_encoder` instances, two `CrossAttention` blocks, and a `Final_Layer`.
- Verified: the model supports optional `double_attention`; otherwise it uses a single lipid/protein pass and optional cross-attention.
- Verified: `CrossAttention` uses two `torch.nn.MultiheadAttention` modules with `HEADS` heads and residual + FFN blocks.
- Verified: `Final_Layer` pools lipid and protein node embeddings separately, concatenates the pooled vectors, and outputs 2 logits.
- Observed: `architecture/loss.py` contains a commented historical PU-loss implementation, but the active loss is `GRAB_loss`.

## Training And Model Selection

- Verified: `read_configuration.py` is a custom parser, not `argparse`.
- Verified: default `ModelConfig` values include `hiddim=128`, `m=4`, `ep=1`, `seed=0`, `batch=16`, `num_workers=4`, `HEADS=8`, `tanimoto_weight=True`, `buryon=True`, `plmon=True`, and `grab_loss=False`.
- Verified: `type_opt` enables AMP only when CUDA is available.
- Verified: `training/new_train.py` initializes `Adam`, computes class weights, creates PyG dataloaders, and logs train/valid/test metrics to TensorBoard and `run/` directories.
- Observed: the code computes validation and test metrics as accuracy, sensitivity, precision, specificity, F1, balanced accuracy, and loss.
- Observed: `training/new_train.py` imports `TensorBoard` and opens a browser when run; importing the file has side effects.

## Available Experiment Evidence

- Observed: the repository contains `data/Processed_Negative_Interaction_Without_Duplicates.csv`, `data/Processed_Negative_int.csv`, `data/grab_pair_graph_edges.csv`, `data/Total_tanimoto_matrix_uint8.npy`, `data/Total_multiple_lipid_batch.npy`, `data/lipid_SMILES_embedding.pkl`, `data/lipid_graphs/lipid_graph_index.csv`, `data/embedding_ESM3/*`, `data/fasta/*`, and `data/graphs/*`.
- Observed: no `metrics_summary.csv`, `feature_contributions.csv`, or completed `research/project_audit.md` existed before this audit.
- Unknown: no run metrics, checkpoint metadata, or seed-aggregated evaluation tables were present in the inspected artifacts.

## Verified Risks And Unknowns

- Verified risk: `training/new_train.py` has runtime side effects at import time, so it must not be imported in tests or audit helpers.
- Verified risk: `Processed_dataset.csv` appears to be a single-column file under default CSV parsing, so its delimiter or formatting requires care before reuse.
- Verified risk: `PLIDataset` uses seed-dependent sampling and split creation; comparisons across runs must record the seed.
- Unknown: no authoritative source revision was recorded in Git metadata from the inspected workspace.
- Unknown: the current report does not establish performance quality, only implementation and data facts.

## Evidence Index

- `training/read_configuration.py` -> `ModelConfig`, CLI flags, default values.
- `dataloader/New_dataloader.py` -> dataset loading, split logic, representation shapes, pair graph construction, lipid graph paths.
- `architecture/interaction_classification.py` -> active module composition and attention flow.
- `architecture/protein_encoder.py` -> protein features, projection, GATv2 stack, optional self-attention.
- `architecture/lipid_encoder.py` -> lipid feature paths and graph-lipid encoder.
- `architecture/cross_attention.py` -> bidirectional attention and masking.
- `architecture/final_layer.py` -> pooling and 2-logit output.
- `architecture/loss.py` -> active `GRAB_loss`.
- `training/new_train.py` -> optimizer, weights, logging, AMP gate, metrics.
- `data/Processed_Negative_Interaction_Without_Duplicates.csv`, `data/Processed_Negative_int.csv`, `data/grab_pair_graph_edges.csv`, `data/lipid_graphs/lipid_graph_index.csv` -> counts and schemas.
