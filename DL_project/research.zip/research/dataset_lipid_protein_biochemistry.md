# Biochemical map of the project lipid-protein dataset

Research date: 2026-06-08

## Scope

This report classifies the proteins and lipids currently present in
`data/Processed_Negative_Interaction_Without_Duplicates.csv` and relates their
recorded positive associations to primary biochemical literature. Dataset
facts and literature facts are kept separate.

The project labels originate from systematic lipid mobilization/association
screens. A positive label is therefore evidence of an assay-dependent
association or mobilization event, not automatically a universal equilibrium
binding constant or physiological cargo assignment
([BIO-PAPER-20260607-001](ltp_lipid_literature.md#bio-paper-20260607-001-systematic-analyses-of-lipid-mobilization-by-human-lipid-transfer-proteins)).

## Dataset snapshot

- Full table: 11,018 rows.
- Proteins: 35.
- Unique `FullIdentityOfLipid` values: 312.
- Rows marked `Interaction == 1`: 756.
- Protein families: 9.
- Lipid prefixes/subclasses: 24, including the ambiguous combined label
  `PG/BMP`.

The previous audit count of 284 unique lipids is stale for the current CSV.
The current count is 312. The generated negative rows also contain
inconsistent `ProteinDomain` values: each protein occurs with multiple
families. Consequently, the family assignments below use the active
`familydic` in `dataloader/New_dataloader.py` and the source positive rows,
not `ProteinDomain` from generated negatives.

## Protein classification

| Family | Dataset proteins | Positive rows | Distinct positive lipids | Dominant recorded lipid classes |
|---|---|---:|---:|---|
| CRAL-TRIO | ATCAY, BNIPL, RLBP1, SEC14L2, SEC14L4, SEC14L5, SEC14L6, TTPA, TTPAL | 204 | 109 | PG, PE, PC, PA, CL |
| GLTP | GLTP, GLTPD1 | 81 | 80 | SM, HexCer, CerP |
| IP_trans | PITPNA, PITPNB, PITPNC1 | 65 | 45 | PC, PG, PA, PI |
| LBP_BPI_CETP | BPI, BPIFB2 | 55 | 38 | PC, PE, PI, PS |
| ML | GM2A | 10 | 10 | PC, PE, PA, PG/BMP |
| OSBP | OSBPL5, OSBPL9 | 8 | 6 | PS, PE |
| START | STARD2, STARD10, STARD11 | 200 | 129 | PC, PE, PG, Cer |
| lipocalin | CRABP2, FABP1, FABP5, FABP7, LCN1, LCN15, PMP2, RBP1, RBP4, RBP5 | 90 | 59 | FA, PC, PG, retinol |
| scp2 | HSDL2, SCP2, SCP2D1 | 43 | 38 | PE, PG/BMP, LPC, LPG |

### CRAL-TRIO

- **SEC14L2** has direct evidence for alpha-tocopherol and PI binding/exchange,
  consistent with its PI records but broader than the dataset's two DAG
  records
  ([Zingg et al., 2014](https://pubmed.ncbi.nlm.nih.gov/24983950/);
  BIO-PAPER-20260608-016).
- **TTPA** is structurally specialized for alpha-tocopherol. Its hydrophobic
  cavity and mobile helical gate explain vitamin E selectivity
  ([Meier et al., 2003](https://pubmed.ncbi.nlm.nih.gov/12899840/);
  BIO-PAPER-20260608-010). The dataset instead records ten phospholipid
  associations for TTPA, which should be interpreted as screen-specific
  mobilization rather than a replacement of its canonical cargo.
- **RLBP1** is represented by broad phospholipid associations in this dataset,
  although its established name and function concern retinaldehyde binding.
  A direct source explaining the exact project phospholipid profile was not
  found.
- **ATCAY, BNIPL, SEC14L4, SEC14L5, SEC14L6, and TTPAL** have weaker or less
  protein-specific biochemical coverage for the exact lipid species recorded
  here. Their labels should not inherit SEC14L2 or TTPA specificity solely
  from the shared fold.

### GLTP

GLTP and GLTPD1 are dominated by sphingolipid records, which agrees with the
family's glycosphingolipid-transfer fold. Human GLTP structures show direct
headgroup recognition and burial of both hydrocarbon chains
([Malinina et al., 2004](https://pubmed.ncbi.nlm.nih.gov/15329726/);
 BIO-PAPER-20260607-002). Changes in chain length and unsaturation alter the
binding mode even when the headgroup is conserved
([Malinina et al., 2006](https://pmc.ncbi.nlm.nih.gov/articles/PMC1618416/);
 BIO-PAPER-20260607-003).

This supports retaining full molecular-species information for HexCer, CerP,
SM, and related lipids rather than classifying all sphingolipids as
interchangeable.

### PITP / IP_trans

- **PITPNA and PITPNB** mainly carry PC, PI, and PG labels. PITP-beta has a
  directly observed PC-filled cavity and transfers both PI and PC
  ([Vordtriede et al., 2005](https://pubmed.ncbi.nlm.nih.gov/16274224/);
  BIO-PAPER-20260608-009).
- **PITPNC1** is different: direct assays support PA and PI transfer with
  little PC binding
  ([Garner et al., 2012](https://pmc.ncbi.nlm.nih.gov/articles/PMC3442557/);
  BIO-PAPER-20260607-005). The dataset profile of ten PA and one PI records is
  therefore biochemically coherent.

Closely related PITP proteins must remain separate model identities because
family membership alone does not determine cargo specificity.

### LBP_BPI_CETP

The BPI structure contains two hydrophobic pockets occupied by PC acyl chains,
providing direct structural evidence that phospholipid accommodation is
possible
([Beamer et al., 1997](https://pubmed.ncbi.nlm.nih.gov/9188532/);
 BIO-PAPER-20260608-014). BPI's primary biological ligand remains bacterial
LPS/lipid A, however. The project's PC-rich BPI and BPIFB2 labels therefore
describe the source screen and should not be summarized as their complete
physiological specificity. Direct BPIFB2 evidence for the exact 24 project
lipids remains sparse.

### ML / GM2A

GM2A canonically extracts GM2 and presents it to lysosomal
beta-hexosaminidase. Direct interaction assays cover GM2 and related
glycosphingolipids
([Hama et al., 1997](https://pubmed.ncbi.nlm.nih.gov/9006924/);
 BIO-PAPER-20260608-015), while membrane studies show that its cavity faces
the bilayer during extraction
([Mathias et al., 2009](https://pubmed.ncbi.nlm.nih.gov/19720032/)).

The dataset's ten GM2A records are mainly glycerophospholipids and contain no
explicit GM2 identity. They are therefore incomplete for canonical GM2A
biology, not evidence that GM2A is primarily a PC-transfer protein.

### OSBP

The dataset contains only six positive lipids for OSBPL5/OSBPL9, mostly PS and
PE. OSBPL9 itself directly extracts sterol and PI4P, and a conserved histidine
pair is required for PI4P extraction
([Liu and Ridgway, 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4177916/);
 BIO-PAPER-20260608-012). ORP5/ORP8 exchange PS and PI4P at ER-plasma membrane
contacts
([Chung et al., 2015](https://pubmed.ncbi.nlm.nih.gov/26206935/);
 BIO-PAPER-20260607-006).

Thus the OSBP-family labels are strongly dependent on protein identity,
organelle localization, counter-ligand, and membrane context. The project
panel does not cover their full canonical sterol/phosphoinositide chemistry.

### START

- **STARD10** has direct transfer evidence for PC and PE and chain-level
  preferences
  ([Olayioye et al., 2005](https://pubmed.ncbi.nlm.nih.gov/15911624/);
  BIO-PAPER-20260607-004). Its PC/PE-dominated dataset profile is consistent
  with this.
- **STARD11/CERT** encloses ceramide in an amphiphilic cavity. Hydrogen bonds,
  stereochemistry, and cavity dimensions determine ceramide recognition and
  chain-length limits
  ([Kudo et al., 2008](https://pubmed.ncbi.nlm.nih.gov/18184806/);
  BIO-PAPER-20260608-011). Its 14 ceramide records are therefore strongly
  supported, whereas its TAG and PC records require assay-specific caution.
- **STARD2/PCTP** is dominated by PC records, consistent with its identity as
  phosphatidylcholine transfer protein. The present report did not add a new
  STARD2-specific source because STARD10 and the systematic screen already
  cover the immediate classification question.

### Lipocalins

- **FABP1, FABP5, FABP7, and PMP2** are represented mainly by fatty acids.
  FABP7 directly binds long-chain fatty acids and shows ligand-dependent
  conformational changes
  ([Bodnariuc et al., 2023](https://pubmed.ncbi.nlm.nih.gov/36751130/);
  BIO-PAPER-20260608-017).
- **RBP1/CRBP1** directly binds all-trans-retinol in an internal cavity
  ([Silvaroli et al., 2016](https://pmc.ncbi.nlm.nih.gov/articles/PMC4861425/);
  BIO-PAPER-20260608-018). The project's RBP1-retinol record is coherent.
- **RBP4, RBP5, and CRABP2** belong to retinoid-binding biology but should not
  automatically inherit CRBP1's exact ligand set or binding geometry.
- **LCN1 and LCN15** have PC/PG-rich project profiles. Those screen
  associations require protein-specific follow-up before being treated as
  canonical cargo specificity.

### SCP2-like proteins

Human SCP2 directly transfers cholesterol and PC between membranes, and
mutational analysis shows that activity depends on residues across the fold
([Seedorf et al., 1994](https://pubmed.ncbi.nlm.nih.gov/8300590/);
 BIO-PAPER-20260608-013). The dataset does not contain cholesterol and gives
SCP2/SCP2D1/HSDL2 mostly glycerophospholipid labels. These labels capture only
part of SCP2 biology.

HSDL2 and SCP2D1 should not inherit all SCP2 transfer properties without
protein-specific evidence. In particular, HSDL2 also contains an enzymatic
dehydrogenase region, so a shared SCP2-like domain is not sufficient to call
the whole protein a generic lipid carrier.

## Lipid classification

The classification below uses the lipid prefix encoded in
`FullIdentityOfLipid`. Counts are unique identities, not rows.

| LIPID MAPS-level category | Dataset subclasses | Unique identities |
|---|---|---:|
| Glycerophospholipids | BMP, CL, LPC, LPE, LPG, PA, PC, PE, PG, PG/BMP, PGP, PI, PS | 205 |
| Sphingolipids | Cer, CerP, Hex2Cer, HexCer, SHexCer, SM | 83 |
| Fatty acyls | FA, FAL | 13 |
| Glycerolipids | DAG, TAG | 10 |
| Prenol lipids | VA (retinol) | 1 |

Subclass counts:

| Subclass | Count | Subclass | Count | Subclass | Count |
|---|---:|---|---:|---|---:|
| BMP | 1 | CL | 10 | Cer | 14 |
| CerP | 10 | DAG | 2 | FA | 12 |
| FAL | 1 | Hex2Cer | 2 | HexCer | 26 |
| LPC | 5 | LPE | 7 | LPG | 4 |
| PA | 11 | PC | 81 | PE | 27 |
| PG | 24 | PG/BMP | 22 | PGP | 3 |
| PI | 7 | PS | 3 | SHexCer | 2 |
| SM | 29 | TAG | 8 | VA | 1 |

The names encode unequal structural resolution. Under LIPID MAPS shorthand,
class, species, molecular species, and complete structure are distinct levels;
lower-resolution names do not uniquely specify sn-position, double-bond
position, or stereochemistry
([Liebisch et al., 2020](https://pubmed.ncbi.nlm.nih.gov/33037133/);
 BIO-PAPER-20260607-007). `PG/BMP` is explicitly ambiguous and must not be
treated as a uniquely identified chemical structure without an additional
resolution rule.

## Evidence hierarchy for interpreting a pair

1. **Direct structure:** ligand is visible in a protein structure, as for
   GLTP-glycosphingolipid, PITP-beta-PC, CERT-ceramide, BPI-PC, TTPA-tocopherol,
   and CRBP1-retinol.
2. **Direct biochemical transfer/extraction:** purified protein moves or
   extracts a defined lipid between membranes.
3. **Direct binding:** affinity, competition, or co-complex measurements with
   a defined ligand.
4. **Cellular transport or mobilization:** depends on localization, membrane
   composition, metabolism, expression, and available counter-ligands.
5. **Systematic association screen:** valuable project label, but may include
   stable co-elution, expression-system lipid, or context-specific
   mobilization.
6. **Family-level inference:** useful for hypothesis generation only; it is
   not direct evidence for a particular protein-lipid pair.

## Main interpretation constraints

- `Interaction == 0` rows were generated as additional combinations. They are
  not documented biochemical non-binding measurements.
- Positive labels from the two source assays are context-dependent and should
  not be collapsed into a universal physical-binding relation.
- Some canonical cargoes are missing from the lipid panel: GM2 for GM2A,
  cholesterol/PI4P for much of OSBP biology, cholesterol for SCP2, and
  LPS/lipid A for BPI.
- A family label does not imply shared specificity. PITPNC1 versus
  PITPNA/PITPNB and STARD10 versus STARD11 are direct counterexamples.
- Lipid class alone is insufficient. GLTP, STARD10, and CERT studies all show
  that chain composition, stereochemistry, and molecular-species resolution
  can alter recognition.
- The current table's `ProteinDomain` column must not be used from negative
  rows until its generation is corrected.

## Sources added in this pass

BIO-PAPER-20260608-009 through BIO-PAPER-20260608-018 were added to
`research/ltp_lipid_literature.md`. Existing sources
BIO-PAPER-20260607-001 through BIO-PAPER-20260607-007 are also cited above.
