# GNN And Architecture Literature

Append-only registry of sources judged useful for this project.

## Entry Format

### AI-PAPER-YYYYMMDD-NNN: Title

- URL:
- DOI:
- Authors:
- Year:
- Venue:
- Relevance:
- Applicable component:
- Evidence supported:
- Limitations:
- Added:

Before adding an entry, search this file by DOI, normalized URL, and title.
Do not add duplicate, inaccessible, retracted, or unverified references.

### AI-PAPER-20260607-001: How Attentive are Graph Attention Networks?

- URL: https://openreview.net/forum?id=F72ximsx7C1
- DOI:
- Authors: Shaked Brody; Uri Alon; Eran Yahav
- Year: 2022
- Venue: International Conference on Learning Representations (ICLR)
- Relevance: Primary source for GATv2, the convolution used by both graph encoders.
- Applicable component: `architecture/protein_encoder.py`; graph branch of `architecture/lipid_encoder.py`.
- Evidence supported: GATv2 provides dynamic attention and is strictly more expressive than the original GAT at comparable parametric cost.
- Limitations: The reported benchmarks do not establish that GATv2 is better than simpler message-passing baselines for this small protein-lipid dataset.
- Added: 2026-06-07

### AI-PAPER-20260607-002: Analyzing Learned Molecular Representations for Property Prediction

- URL: https://pubs.acs.org/doi/10.1021/acs.jcim.9b00237
- DOI: 10.1021/acs.jcim.9b00237
- Authors: Kevin Yang; Kyle Swanson; Wengong Jin; Connor Coley; Philipp Eiden; Hua Gao; Angel Guzman-Perez; Timothy Hopper; Brian Kelley; Miriam Mathea; Andrew Palmer; Tommi Jaakkola; Klavs Jensen; Regina Barzilay
- Year: 2019
- Venue: Journal of Chemical Information and Modeling
- Relevance: Provides a directed-bond message-passing baseline and an evaluation of learned molecular graphs against fixed fingerprints.
- Applicable component: Chemical lipid graph encoder, lipid baselines, and split design.
- Evidence supported: Molecular representation rankings depend on evaluation setup; scaffold-aware evaluation is more informative than random splitting, and fingerprints can remain competitive on small datasets.
- Limitations: The tasks are molecular property prediction rather than protein-lipid pair classification, so performance gains cannot be transferred directly.
- Added: 2026-06-07

### AI-PAPER-20260607-003: Deep Sets

- URL: https://papers.nips.cc/paper_files/paper/2017/hash/f22e4747da1aa27e363d86d40ff442fe-Abstract.html
- DOI:
- Authors: Manzil Zaheer; Satwik Kottur; Siamak Ravanbakhsh; Barnabas Poczos; Ruslan Salakhutdinov; Alexander J. Smola
- Year: 2017
- Venue: Advances in Neural Information Processing Systems 30
- Relevance: Supplies the permutation-invariant foundation for aggregating a variable set of lipid fragments.
- Applicable component: `lipid_fragments_mask`, disconnected lipid components, and final lipid pooling.
- Evidence supported: Set-valued inputs should be processed with permutation-invariant functions; this supports explicit atom-to-fragment and fragment-to-lipid aggregation.
- Limitations: The paper does not prescribe a chemically optimal fragment representation or show protein-lipid interaction results.
- Added: 2026-06-07

### AI-PAPER-20260607-004: DTI-Voodoo: machine learning over interaction networks and ontology-based background knowledge predicts drug-target interactions

- URL: https://academic.oup.com/bioinformatics/article/37/24/4835/6329632
- DOI: 10.1093/bioinformatics/btab548
- Authors: Tilman Hinnerichs; Robert Hoehndorf
- Year: 2021
- Venue: Bioinformatics
- Relevance: Directly studies entity overlap, hub bias, unknown-as-negative labels, and evaluation protocols in pairwise drug-target prediction.
- Applicable component: Dataset splitting, GRAB evaluation, entity-frequency baselines, and per-protein metrics.
- Evidence supported: Pair-level random splits can exploit repeated entities and interaction-degree bias; entity-based evaluation measures a different and harder generalization problem.
- Limitations: Drug-target datasets and auxiliary networks differ from the project's curated LTP-lipid setting.
- Added: 2026-06-07

### AI-PAPER-20260607-005: Improving compound-protein interaction prediction by building up highly credible negative samples

- URL: https://academic.oup.com/bioinformatics/article/31/12/i221/216307
- DOI: 10.1093/bioinformatics/btv256
- Authors: Hui Liu; Jianjiang Sun; Jihong Guan; Jie Zheng; Shuigeng Zhou
- Year: 2015
- Venue: Bioinformatics
- Relevance: Evaluates the effect of negative-sample construction in compound-protein interaction prediction.
- Applicable component: Provenance and sampling of rows with `Interaction=0`.
- Evidence supported: Random unknown pairs may contain undiscovered positives; screened negatives and blockwise evaluation can materially change measured performance.
- Limitations: Its negative-screening assumptions require similarity and auxiliary evidence that may not all be available for the current dataset.
- Added: 2026-06-07

### AI-PAPER-20260607-006: Positive-Unlabeled Learning with Non-Negative Risk Estimator

- URL: https://papers.nips.cc/paper/2017/hash/7cce53cf90577442771720a370c3c723-Abstract.html
- DOI:
- Authors: Ryuichi Kiryo; Gang Niu; Marthinus C. du Plessis; Masashi Sugiyama
- Year: 2017
- Venue: Advances in Neural Information Processing Systems 30
- Relevance: Provides a deep-learning objective for positive and unlabeled data when zero labels are not verified negatives.
- Applicable component: Historical PU-loss branch and the active binary training objective.
- Evidence supported: The non-negative PU risk estimator reduces the overfitting failure of unbiased PU estimators with flexible models and limited positive data.
- Limitations: It requires a justified class prior and the assumption that the unlabeled pool follows the PU setting; neither is established by the current artifacts.
- Added: 2026-06-07

### AI-PAPER-20260608-001: Structure-aware Interactive Graph Neural Networks for the Prediction of Protein-Ligand Binding Affinity

- URL: https://dl.acm.org/doi/10.1145/3447548.3467311
- DOI: 10.1145/3447548.3467311
- Authors: Shuangli Li; Jingbo Zhou; Tong Xu; Liang Huang; Fan Wang; Haoyi Xiong; Weili Huang; Dejing Dou; Hui Xiong
- Year: 2021
- Venue: Proceedings of the 27th ACM SIGKDD Conference on Knowledge Discovery and Data Mining (KDD)
- Relevance: Primary structure-based protein-ligand example in which graph representations are updated iteratively while retaining explicit geometric relations.
- Applicable component: Repeated protein/lipid graph blocks, chemical-edge reuse, and protein-lipid interaction aggregation.
- Evidence supported: SIGN iteratively updates node and edge embeddings with distance and angle information and models explicit protein-ligand interactions through pairwise interactive pooling; repeated interaction processing can therefore have structural meaning when each stage preserves and uses the relevant relations.
- Limitations: SIGN operates on 3D protein-ligand complex graphs and binding-affinity regression datasets much larger and richer than this project's separate protein and lipid graphs. It does not validate the current `double_attention` implementation or establish that an extra block will help this dataset.
- Added: 2026-06-08

### AI-PAPER-20260608-002: Demystifying Oversmoothing in Attention-Based Graph Neural Networks

- URL: https://papers.nips.cc/paper_files/paper/2023/hash/6e4cdfdd909ea4e34bfc85a12774cba0-Abstract-Conference.html
- DOI: 10.52202/075280-1524
- Authors: Xinyi Wu; Amir Ajorlou; Zihui Wu; Ali Jadbabaie
- Year: 2023
- Venue: Advances in Neural Information Processing Systems 36 (NeurIPS)
- Relevance: Primary theoretical analysis of representation degradation when attention-based graph layers are stacked.
- Applicable component: Repeated GATv2 and self-attention blocks in the protein and lipid encoders.
- Evidence supported: Graph attention does not by itself prevent oversmoothing; under the analyzed assumptions, attention-based GNNs can lose expressive power exponentially with depth.
- Limitations: The result is theoretical and does not determine the optimal depth for this shallow architecture. Oversmoothing is distinct from statistical overfitting caused by the small number of labelled protein-lipid pairs.
- Added: 2026-06-08

### AI-PAPER-20260608-003: SS-GNN: A Simple-Structured Graph Neural Network for Affinity Prediction

- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC10308598/
- DOI: 10.1021/acsomega.3c00085
- Authors: Shuke Zhang; Yanzhao Jin; Tianmeng Liu; Qi Wang; Zhaohui Zhang; Shuliang Zhao; Bo Shan
- Year: 2023
- Venue: ACS Omega
- Relevance: Direct lightweight structure-based protein-ligand GNN reference.
- Applicable component: Model-capacity baselines, graph depth, interaction aggregation, and parameter-count comparison.
- Evidence supported: A two-layer GIN plus edge MLP and edge-based atom-pair aggregation achieved competitive PDBbind affinity results with approximately 0.6 million parameters; a compact interaction graph can be competitive with more elaborate models.
- Limitations: SS-GNN uses 3D protein-ligand complexes and thousands of affinity-labelled samples. Its reported performance and preferred representation do not transfer directly to a binary LTP-lipid dataset of about 1,100 sampled train pairs.
- Added: 2026-06-08

### AI-PAPER-20260608-004: InteractionGraphNet: A Novel and Efficient Deep Graph Representation Learning Framework for Accurate Protein-Ligand Interaction Predictions

- URL: https://pubs.acs.org/doi/10.1021/acs.jmedchem.1c01830
- DOI: 10.1021/acs.jmedchem.1c01830
- Authors: Dejun Jiang; Chang-Yu Hsieh; Zhenxing Wu; Yu Kang; Jike Wang; Ercheng Wang; Ben Liao; Chao Shen; Lei Xu; Jian Wu; Dongsheng Cao; Tingjun Hou
- Year: 2021
- Venue: Journal of Medicinal Chemistry
- Relevance: Direct example of staged graph processing for intramolecular and intermolecular protein-ligand relations.
- Applicable component: Ordering of protein/lipid graph encoding and cross-molecule interaction blocks.
- Evidence supported: IGN stacks independent graph-convolution modules to learn intramolecular relations first and intermolecular relations second, supporting explicit separation between structural encoding and interaction encoding.
- Limitations: IGN has access to a 3D bound complex and explicit intermolecular edges. The current project has separate protein and lipid representations, so cross-attention is not equivalent to IGN's physical interaction graph.
- Added: 2026-06-08

### AI-PAPER-20260608-005: Geometric Interaction Graph Neural Network for Predicting Protein-Ligand Binding Affinities from 3D Structures

- URL: https://pubmed.ncbi.nlm.nih.gov/36794930/
- DOI: 10.1021/acs.jpclett.2c03906
- Authors: Ziduo Yang; Weihe Zhong; Qiujie Lv; Tiejun Dong; Calvin Yu-Chian Chen
- Year: 2023
- Venue: The Journal of Physical Chemistry Letters
- Relevance: Shows how covalent and noncovalent relations can be combined in a geometry-aware interaction graph.
- Applicable component: Protein-lipid cross-interaction representation and the distinction between topology-only attention and physical interaction edges.
- Evidence supported: GIGN integrates covalent and noncovalent edges during message passing and enforces translation and rotation invariance for 3D complexes; explicit physical relations provide a stronger structural inductive bias than unrestricted cross-attention.
- Limitations: The project does not contain experimentally resolved protein-lipid complex coordinates or protein-lipid contact edges, so GIGN cannot be reproduced from the current inputs.
- Added: 2026-06-08

### AI-PAPER-20260608-006: Understanding Over-Squashing and Bottlenecks on Graphs via Curvature

- URL: https://openreview.net/forum?id=7UmjRGzp-A
- DOI:
- Authors: Jake Topping; Francesco Di Giovanni; Benjamin Paul Chamberlain; Xiaowen Dong; Michael M. Bronstein
- Year: 2022
- Venue: International Conference on Learning Representations (ICLR), Oral
- Relevance: Primary analysis of information loss when distant graph signals must pass through narrow structural bottlenecks.
- Applicable component: Protein graph depth and any claim that adding GAT layers necessarily captures long-range structural information.
- Evidence supported: Over-squashing arises from graph bottlenecks and can make node representations insensitive to distant information; simply stacking message-passing layers does not guarantee effective long-range propagation.
- Limitations: The paper does not analyze this project's residue graphs or show that they contain harmful curvature bottlenecks. Rewiring physical protein graphs may also remove biochemical meaning.
- Added: 2026-06-08

### AI-PAPER-20260608-007: Leak Proof PDBBind: A Reorganized Data Set of Protein-Ligand Complexes for More Generalizable Binding Affinity Prediction

- URL: https://pubmed.ncbi.nlm.nih.gov/41486605/
- DOI: 10.1021/acs.jpcb.5c08598
- Authors: Jie Li; Xingyi Guan; Oufan Zhang; Kunyang Sun; Yingze Wang; Dorian Bagni; Teresa Head-Gordon
- Year: 2026
- Venue: The Journal of Physical Chemistry B
- Relevance: Recent direct evidence that protein and ligand similarity contamination changes structure-based interaction evaluation.
- Applicable component: Cold-protein, cold-lipid, and double-cold split design.
- Evidence supported: The authors construct train, validation, and test partitions controlling protein and ligand sequence/structural similarity and show that retraining on the leak-controlled split changes generalization results for multiple scoring functions.
- Limitations: PDBbind affinity regression, sequence clusters, and 3D ligand similarity differ from this project's protein-family exclusions and lipid identities. The exact LP-PDBBind thresholds should not be copied without adaptation.
- Added: 2026-06-08
