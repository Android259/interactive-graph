# LTP And Lipid Literature

Append-only registry of biochemical and molecular sources judged useful for
this project.

## Entry Format

### BIO-PAPER-YYYYMMDD-NNN: Title

- URL:
- DOI:
- Authors:
- Year:
- Venue or database:
- LTP/lipid scope:
- Relevance:
- Evidence supported:
- Limitations:
- Added:

Before adding an entry, search this file by DOI, normalized URL, and title.
Do not add duplicate, inaccessible, retracted, or unverified references.

### BIO-PAPER-20260607-001: Systematic analyses of lipid mobilization by human lipid transfer proteins

- URL: https://www.nature.com/articles/s41586-025-10040-y
- DOI: 10.1038/s41586-025-10040-y
- Authors: Kevin Titeca et al.
- Year: 2026
- Venue or database: Nature
- LTP/lipid scope: Systematic in-cellulo and in-vitro lipid mobilization screens across human LTP families.
- Relevance: This is the primary source matching the project's 9-family, in-cellulo/in-vitro interaction resource. It defines the experimental meaning and limitations of the positive associations used by the project.
- Evidence supported: LTPs often mobilize several lipid classes; headgroup and acyl-chain structure both contribute to selectivity; the two assays are complementary and context-dependent; only lipids co-eluting with an LTP were considered potential binders; the in-cellulo assay is specific to overexpressed proteins in dividing HEK293 cells, while the in-vitro assay uses recombinant proteins and simplified membranes.
- Limitations: Mobilization or stable association is not equivalent to universal physical binding in every cellular context. Some in-vitro ligands may originate from bacterial expression or simplified membrane conditions. Absence from a reported LTP-lipid list is not documented experimental non-binding.
- Added: 2026-06-07

### BIO-PAPER-20260607-002: Structural basis for glycosphingolipid transfer specificity

- URL: https://pubmed.ncbi.nlm.nih.gov/15329726/
- DOI: 10.1038/nature02856
- Authors: Lucy Malinina, Margarita L. Malakhova, Alexei Teplov, Rhoderick E. Brown, Dinshaw J. Patel
- Year: 2004
- Venue or database: Nature
- LTP/lipid scope: Apo and lactosylceramide-bound human GLTP structures with mutational and functional analysis.
- Relevance: Provides direct structural evidence that a lipid label cannot be reduced to headgroup class alone: sugar-amide recognition, oriented chain insertion, pocket shape, and conformational gating determine GLTP binding.
- Evidence supported: GLTP recognizes and anchors the glycosphingolipid sugar-amide headgroup and encapsulates both lipid chains in a hydrophobic tunnel; binding involves adaptive recognition and a gate-like conformational change.
- Limitations: One LTP family and a limited ligand set; the structures do not establish rules for all LTP folds or all assay contexts.
- Added: 2026-06-07

### BIO-PAPER-20260607-003: The liganding of glycolipid transfer protein is controlled by glycolipid acyl structure

- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC1618416/
- DOI: 10.1371/journal.pbio.0040362
- Authors: Lucy Malinina, Margarita L. Malakhova, Alexander T. Kanack, Min Lu, Rhoderick E. Brown, Dinshaw J. Patel
- Year: 2006
- Venue or database: PLOS Biology
- LTP/lipid scope: Crystal structures and binding measurements for human GLTP with glycosphingolipids varying in acyl-chain length, unsaturation, and sugar composition.
- Relevance: Directly supports retaining molecular-species information such as chain length and unsaturation instead of treating all members of one lipid class as interchangeable.
- Evidence supported: Acyl-chain chemistry changes how a glycosphingolipid occupies the GLTP tunnel, including sphingosine-in and sphingosine-out modes, despite conserved headgroup anchoring.
- Limitations: Findings are specific to GLTP and the tested synthetic glycosphingolipids; they do not prove that every chain-level difference changes the binary project label.
- Added: 2026-06-07

### BIO-PAPER-20260607-004: StarD10, a START domain protein overexpressed in breast cancer, functions as a phospholipid transfer protein

- URL: https://pubmed.ncbi.nlm.nih.gov/15911624/
- DOI: 10.1074/jbc.M413330200
- Authors: Antje Olayioye et al.
- Year: 2005
- Venue or database: Journal of Biological Chemistry
- LTP/lipid scope: Experimental binding and transfer specificity of human STARD10.
- Relevance: Demonstrates family-member and molecular-species specificity within the START domain class represented in the dataset.
- Evidence supported: STARD10 binds and transfers PC and PE and preferentially selects species with palmitoyl or stearoyl sn-1 chains and unsaturated 18:1 or 18:2 sn-2 chains.
- Limitations: Uses a defined protein and assay systems; preferences cannot be generalized unchanged to every START protein or lipid composition.
- Added: 2026-06-07

### BIO-PAPER-20260607-005: Phosphatidylinositol transfer protein, cytoplasmic 1 (PITPNC1) binds and transfers phosphatidic acid

- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC3442557/
- DOI: 10.1074/jbc.M112.375840
- Authors: Kathryn Garner, Antony N. Hunt, George Koster, Peter Somerharju, Eduard Groves, Mark Li, Shamshad Cockcroft
- Year: 2012
- Venue or database: Journal of Biological Chemistry
- LTP/lipid scope: Binding and transfer assays for human PITPNC1/RdgB-beta.
- Relevance: Shows that closely related PITP classes have materially different ligand profiles and that PA, PI, PC, and bacterial preload cannot be interpreted from family name alone.
- Evidence supported: PITPNC1 binds and transfers PA and PI, binds little PC, and recombinant preparations can carry expression-system lipids.
- Limitations: Assays use recombinant proteins, permeabilized cells, and selected lipid systems; detected transfer does not define all physiological cargoes.
- Added: 2026-06-07

### BIO-PAPER-20260607-006: PI4P/phosphatidylserine countertransport at ORP5- and ORP8-mediated ER-plasma membrane contacts

- URL: https://pubmed.ncbi.nlm.nih.gov/26206935/
- DOI: 10.1126/science.aab1370
- Authors: Jeeyun Chung et al.
- Year: 2015
- Venue or database: Science
- LTP/lipid scope: Cellular and biochemical analysis of ORP5/ORP8-mediated PI4P and PS exchange at membrane contact sites.
- Relevance: Establishes that an LTP-lipid relation can depend on membrane localization, a counter-ligand, and a metabolic gradient, none of which is represented by an isolated 2D lipid graph.
- Evidence supported: ORP5 and ORP8 exchange PI4P and PS between ER and plasma membrane contact sites, coupled to PI4P metabolism.
- Limitations: ORP5/ORP8 are not identical to every OSBP-family protein in the project; the study does not quantify general pairwise compatibility outside its cellular system.
- Added: 2026-06-07

### BIO-PAPER-20260607-007: Update on LIPID MAPS classification, nomenclature, and shorthand notation for MS-derived lipid structures

- URL: https://pubmed.ncbi.nlm.nih.gov/33037133/
- DOI: 10.1194/jlr.S120001025
- Authors: Gerhard Liebisch et al.
- Year: 2020
- Venue or database: Journal of Lipid Research / LIPID MAPS
- LTP/lipid scope: Standardized hierarchical representation of lipid identity at species, molecular-species, full-structure, and complete-structure resolution.
- Relevance: Supplies an authoritative basis for recording how much structural information is actually known before generating or assigning a SMILES graph.
- Evidence supported: Lipid annotations have explicit resolution levels; lower-resolution MS annotations do not uniquely determine chain positions, double-bond positions, or stereochemistry.
- Limitations: A nomenclature standard, not an LTP-binding experiment; it defines identity uncertainty but not its quantitative effect on model performance.
- Added: 2026-06-07

### BIO-PAPER-20260607-008: MoleculeNet: a benchmark for molecular machine learning

- URL: https://pubs.rsc.org/en/content/articlelanding/2018/sc/c7sc02664a
- DOI: 10.1039/C7SC02664A
- Authors: Zhenqin Wu, Bharath Ramsundar, Evan N. Feinberg, Joseph Gomes, Caleb Geniesse, Aneesh S. Pappu, Karl Leswing, Vijay Pande
- Year: 2018
- Venue or database: Chemical Science
- LTP/lipid scope: Molecular machine-learning benchmark design and chemically structured dataset splitting.
- Relevance: Supports evaluation beyond random row splits when the scientific target is generalization to chemically distinct lipids.
- Evidence supported: Random splitting can give an inadequate estimate for chemical generalization; structure-aware splits provide a harder evaluation of performance on different molecular frameworks.
- Limitations: The benchmark concerns molecular-property datasets rather than bipartite LTP-lipid interaction matrices. Many lipids are acyclic, so Bemis-Murcko scaffold splitting alone is not sufficient for this project.
- Added: 2026-06-07

### BIO-PAPER-20260608-009: Structure of PITPbeta in complex with phosphatidylcholine: comparison of structure and lipid transfer to other PITP isoforms

- URL: https://pubmed.ncbi.nlm.nih.gov/16274224/
- DOI: 10.1021/bi051191r
- Authors: Paul B. Vordtriede, Chuong N. Doan, Jacqueline M. Tremblay, George M. Helmkamp Jr, Marilyn D. Yoder
- Year: 2005
- Venue or database: Biochemistry
- LTP/lipid scope: Structure of rat PITP-beta bound to phosphatidylcholine, with transfer assays and comparison to PITP-alpha.
- Relevance: Provides direct structural support for the PI/PC cargo range represented by the project's PITPNA and PITPNB records and shows that closely related isoforms can differ in transfer behavior.
- Evidence supported: PITP-beta encloses phosphatidylcholine in a hydrophobic cavity and can exchange PI and PC between membranes; sequence changes inside the cavity contribute to isoform-specific behavior.
- Limitations: The structure is rat PITP-beta and one bound PC species. It does not establish every human PITP-lipid pair or the meaning of an absent project label.
- Added: 2026-06-08

### BIO-PAPER-20260608-010: The molecular basis of vitamin E retention: structure of human alpha-tocopherol transfer protein

- URL: https://pubmed.ncbi.nlm.nih.gov/12899840/
- DOI: 10.1016/S0022-2836(03)00724-1
- Authors: Reto Meier, Takashi Tomizaki, Clemens Schulze-Briese, Ulrich Baumann, Achim Stocker
- Year: 2003
- Venue or database: Journal of Molecular Biology
- LTP/lipid scope: Human alpha-tocopherol transfer protein structure and molecular basis of alpha-tocopherol recognition.
- Relevance: Directly supports interpreting TTPA as a vitamin E-selective transfer protein rather than a general phospholipid carrier.
- Evidence supported: Alpha-tocopherol is enclosed in a hydrophobic pocket whose mobile helical segment adopts open and closed conformations; pocket interactions explain selective retention of alpha-tocopherol.
- Limitations: Structural selectivity for tocopherols does not explain every phospholipid association reported for TTPA in the systematic mobilization screen.
- Added: 2026-06-08

### BIO-PAPER-20260608-011: Structural basis for specific lipid recognition by CERT responsible for nonvesicular trafficking of ceramide

- URL: https://pubmed.ncbi.nlm.nih.gov/18184806/
- DOI: 10.1073/pnas.0709191105
- Authors: Norio Kudo, Keigo Kumagai, Nario Tomishige, Toshiyuki Yamaji, Soichi Wakatsuki, Masahiro Nishijima, Kentaro Hanada, Ryuichi Kato
- Year: 2008
- Venue or database: Proceedings of the National Academy of Sciences
- LTP/lipid scope: Apo and ceramide-bound structures plus extraction and transfer assays for the CERT/STARD11 START domain.
- Relevance: Directly explains the project's strong STARD11-ceramide signal and why ceramide chain length and stereochemistry cannot be discarded.
- Evidence supported: CERT encloses one ceramide in an amphiphilic cavity; hydrogen bonds recognize the ceramide polar groups, while cavity shape imposes stereochemical and acyl-chain-length selectivity.
- Limitations: Tested isolated START domain and selected ceramides; full-length cellular transport additionally depends on membrane targeting and regulation.
- Added: 2026-06-08

### BIO-PAPER-20260608-012: Characterization of the sterol and phosphatidylinositol 4-phosphate binding properties of Golgi-associated OSBP-related protein 9

- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC4177916/
- DOI: 10.1371/journal.pone.0108368
- Authors: Ximing Liu, Neale D. Ridgway
- Year: 2014
- Venue or database: PLOS ONE
- LTP/lipid scope: Sterol and PI4P extraction/binding by long and short ORP9 isoforms.
- Relevance: Supplies protein-specific evidence for OSBPL9 and shows that canonical ORP9 cargoes are sterols and PI4P rather than the PE/PS labels alone visible in this dataset.
- Evidence supported: ORP9 extracts sterol and PI4P from liposomes; a conserved histidine pair is specifically required for PI4P extraction.
- Limitations: Uses recombinant proteins, model membranes, and PI4P/sterol ligands that are largely absent from the project's lipid panel.
- Added: 2026-06-08

### BIO-PAPER-20260608-013: Structure-activity studies of human sterol carrier protein 2

- URL: https://pubmed.ncbi.nlm.nih.gov/8300590/
- DOI: 10.1016/S0021-9258(17)41988-0
- Authors: Udo Seedorf, Susanne Scheek, Thomas Engel, Christian Steif, Hans-Joachim Hinz, Gerd Assmann
- Year: 1994
- Venue or database: Journal of Biological Chemistry
- LTP/lipid scope: Mutational analysis of human SCP2 sterol-carrier, cholesterol-transfer, and phosphatidylcholine-transfer activities.
- Relevance: Provides direct functional evidence that SCP2 is a broad carrier whose activity depends on residues distributed across its compact fold.
- Evidence supported: Recombinant human SCP2 transfers cholesterol and PC between membranes; N-terminal, Asp70, and C-terminal residues are required for full activity.
- Limitations: Does not test the full phospholipid panel used in the project and does not establish equivalent specificity for SCP2D1 or HSDL2.
- Added: 2026-06-08

### BIO-PAPER-20260608-014: Crystal structure of human BPI and two bound phospholipids at 2.4 angstrom resolution

- URL: https://pubmed.ncbi.nlm.nih.gov/9188532/
- DOI: 10.1126/science.276.5320.1861
- Authors: Lisa J. Beamer, Stephen F. Carroll, David Eisenberg
- Year: 1997
- Venue or database: Science
- LTP/lipid scope: Human bactericidal/permeability-increasing protein structure with two bound phosphatidylcholine molecules.
- Relevance: Gives direct structural evidence for phospholipid accommodation by BPI while preserving its primary biological interpretation as an LPS-binding antimicrobial protein.
- Evidence supported: The two homologous BPI domains contain apolar pockets occupied by PC acyl chains; the architecture suggests a mechanism for binding lipid A acyl chains.
- Limitations: Bound PC may reflect purification or structural stabilization and does not make PC the sole or principal physiological BPI ligand.
- Added: 2026-06-08

### BIO-PAPER-20260608-015: Interaction of GM2 activator protein with glycosphingolipids

- URL: https://pubmed.ncbi.nlm.nih.gov/9006924/
- DOI: 10.1074/jbc.272.5.2828
- Authors: Yoshio Hama, Yu-Teh Li, Su-Chen Li
- Year: 1997
- Venue or database: Journal of Biological Chemistry
- LTP/lipid scope: Direct interaction assays between human GM2 activator protein and GM2 or related glycosphingolipids.
- Relevance: Establishes the canonical lipid scope of GM2A, which is not well represented by the mostly glycerophospholipid project labels for this protein.
- Evidence supported: GM2 activator interacts with GM2 and additional glycosphingolipids and presents membrane-embedded GM2 for enzymatic hydrolysis.
- Limitations: The assay addresses lysosomal glycosphingolipid handling, not the systematic screen's PC-rich associations.
- Added: 2026-06-08

### BIO-PAPER-20260608-016: Modulation of phosphorylation of tocopherol and phosphatidylinositol by hTAP1/SEC14L2-mediated lipid exchange

- URL: https://pubmed.ncbi.nlm.nih.gov/24983950/
- DOI: 10.1371/journal.pone.0101550
- Authors: Jean-Marc Zingg, Roksan Libinaki, Mohsen Meydani, Angelo Azzi
- Year: 2014
- Venue or database: PLOS ONE
- LTP/lipid scope: Recombinant human SEC14L2/hTAP1 binding and exchange of alpha-tocopherol and phosphatidylinositol.
- Relevance: Supports interpreting SEC14L2 as a two-ligand Sec14-like carrier and is consistent with the project's SEC14L2-PI observations.
- Evidence supported: SEC14L2 binds alpha-tocopherol and phosphatidylinositol and can alter their presentation to phosphorylation reactions through lipid exchange.
- Limitations: Enzyme-coupled and recombinant assays do not define all cellular cargoes or prove direct transfer for every project lipid species.
- Added: 2026-06-08

### BIO-PAPER-20260608-017: A combined computational-biophysical approach to understanding fatty acid binding to FABP7

- URL: https://pubmed.ncbi.nlm.nih.gov/36751130/
- DOI: 10.1016/j.bpj.2023.02.003
- Authors: Iulia Bodnariuc, Stefan Lenz, Margaret Renaud-Young, Tanille M. Butler, Hiroaki Ishida, Hans J. Vogel, Justin L. MacCallum
- Year: 2023
- Venue or database: Biophysical Journal
- LTP/lipid scope: Fatty-acid binding to FABP7 studied by NMR, biophysical assays, and molecular simulation.
- Relevance: Provides protein-specific support for the fatty-acid labels assigned to FABP7 and demonstrates ligand-dependent conformational behavior.
- Evidence supported: FABP7 binds long-chain fatty acids including DHA; binding reduces protein conformational heterogeneity and perturbs residues near a nuclear localization signal.
- Limitations: A focused fatty-acid set was tested, and behavior at physiological temperature did not show simple strong selectivity among all tested ligands.
- Added: 2026-06-08

### BIO-PAPER-20260608-018: Ligand binding induces conformational changes in human cellular retinol-binding protein 1 revealed by atomic resolution crystal structures

- URL: https://pmc.ncbi.nlm.nih.gov/articles/PMC4861425/
- DOI: 10.1074/jbc.M116.714535
- Authors: Joseph A. Silvaroli, Jason M. Arne, Sylwia Chelstowska, Philip D. Kiser, Sayan Banerjee, Marcin Golczak
- Year: 2016
- Venue or database: Journal of Biological Chemistry
- LTP/lipid scope: Apo, all-trans-retinol-bound, and retinylamine-bound human CRBP1/RBP1 structures.
- Relevance: Directly supports the retinol identity associated with RBP1 and shows why retinoids should not be merged with generic fatty-acid or phospholipid labels.
- Evidence supported: CRBP1 encloses all-trans-retinol in an internal cavity and undergoes ligand-dependent conformational changes involved in uptake and release.
- Limitations: Structural binding to retinol does not establish equivalence across other retinoid-binding proteins RBP4, RBP5, or CRABP2.
- Added: 2026-06-08
