# Biochemistry Proposals Draft

Staging entries produced by the biochemical research pass. These entries are
ready for review and later transfer into `research/proposals.md`; this file
does not alter the shared proposal registry.

## Project Audit Snapshot

- Audited input: `data/Processed_Negative_Interaction_Without_Duplicates.csv`.
- Rows: 11,018; labels: 756 positive and 10,262 generated negative.
- The first 760 rows contain 756 positives and 4 negatives. The dataloader
  treats all first 760 rows as the positive block and samples 5.6% of later
  negatives.
- Negative construction takes the Cartesian product of observed proteins and
  lipid identities, then labels absent pairs as zero. It does not establish
  experimental non-binding.
- Default seed-0 sampled data contain 1,134 train, 100 validation, and 100 test
  rows. Train/test share 31 of 35 proteins, all 9 protein domains, 85 lipid
  names, 49 exact `SmileGlobal` strings, and 26 exact `SmileFragment` strings.
- The source data contain two assay contexts, `in vitro` and `in cellulo`.
  Positive rows comprise 494 in-vitro and 262 in-cellulo observations.
- Every row has either `SmileGlobal` or `SmileFragment`; no row lacks both.
  All 54,627 parsed SMILES tokens were accepted by RDKit in this audit.
- Of 47,113 global-SMILES tokens with at least one detected chiral centre,
  40,778 contain at least one unassigned centre. Of 7,024 fragment-SMILES
  tokens, 6,250 contain at least one unassigned centre. Counts include
  repeated structures across rows.
- There are no conflicting labels for the same
  `(LTPProtein, FullIdentityOfLipid)` key. Coarser identifiers do collapse
  distinct molecular identities: 27 `(LTPProtein, Lipid)` groups and 43
  `(LTPProtein, SmileGlobal)` groups contain both labels.
- The chemical-graph path preserves isomeric SMILES and encodes 2D atom and
  covalent-bond features. It does not encode assay membrane composition,
  protein localization, counter-ligands, pH, or a measured bound conformation.

## Final BIO-PROP Entries

#### BIO-PROP-20260607-001: Treat generated zero labels as unlabeled unless non-binding is documented

- Status: proposed
- Priority: critical
- Project observation: `preprocessing/generate_negative_interaction.py` labels every protein-lipid identity absent from the positive table as `Interaction=0`. The resulting CSV contains 10,262 such rows versus 756 positives. The source study reports detected LTP-associated lipids after assay-specific filtering; it does not define every unreported Cartesian pair as an experimentally verified non-binder.
- Biochemical proposal: Represent Cartesian-complement pairs as unlabeled or low-confidence negatives. Reserve a verified-negative tier for pairs supported by an assay with adequate lipid availability, successful protein purification, and an explicit non-detection criterion. Train and report a positive-unlabeled baseline alongside the current binary baseline.
- Mechanism or rationale: Non-detection can reflect assay context, lipid abundance, bacterial preload, protein activation, localization, counter-ligands, or analytical sensitivity. Converting all missing observations into biological non-interactions introduces asymmetric label noise.
- Supporting sources: BIO-PAPER-20260607-001; https://www.nature.com/articles/s41586-025-10040-y
- Required data or audit: Recover the original per-protein assay coverage, protein-expression/purification status, detectable lipid universe, co-elution filters, and replicate-level evidence. Assign `positive`, `verified_negative`, or `unlabeled` plus assay and confidence fields without changing the original raw evidence.
- Control and ablation: Compare current binary labels with (1) PU loss using all complement pairs as unlabeled, (2) high-confidence negatives only, and (3) confidence-weighted labels. Keep protein/lipid splits and sampled positive rows identical.
- Validation metric: Validation balanced accuracy and PR-AUC on independently supported positives plus verified negatives; positive recall and calibration reported by assay and LTP family. Do not select the model on Cartesian-complement test labels alone.
- Falsification criterion: Reject the proposal if the source audit demonstrates that complement pairs were all experimentally assayed under adequate conditions and explicitly passed a validated non-binding threshold, or if repeated-seed comparisons show no improvement in verified-label evaluation or calibration.
- Confounders: Verified negatives may be scarce and biased toward well-characterized proteins or abundant lipids; PU class-prior estimation may itself be uncertain.
- Evidence strength: direct for how project negatives are generated; direct for assay/context limitations in the source study; indirect for the expected metric effect.
- Added: 2026-06-07

#### BIO-PROP-20260607-002: Add protein-cold, lipid-cold, and dual-cold evaluation splits

- Status: proposed
- Priority: critical
- Project observation: The default split is a random row split after negative downsampling. In the seed-0 audit, train and test share 31 proteins, all 9 protein domains, 85 lipid names, and many exact SMILES strings. This primarily measures interpolation over familiar entities. A standard ring-scaffold split is also insufficient because most audited lipid representations are acyclic.
- Biochemical proposal: Retain random split as an interpolation baseline, but add three leakage-controlled evaluations: unseen LTP/subgroup, unseen lipid identity or chemical cluster, and unseen protein plus unseen lipid. Keep every occurrence of the same full lipid identity and canonical structure in one partition.
- Mechanism or rationale: Protein-family and lipid-identity overlap permits memorization of family priors, headgroup frequency, and repeated molecular species. Cold splits distinguish recognition of new combinations from generalization to genuinely unseen proteins or lipid chemotypes.
- Supporting sources: BIO-PAPER-20260607-008; BIO-PAPER-20260607-007
- Required data or audit: Canonical protein IDs, LTP family/subfamily, `FullIdentityOfLipid`, canonical isomeric SMILES, lipid class, LIPID MAPS resolution level, and a chemical clustering rule suitable for acyclic lipids, such as ECFP similarity clustering combined with headgroup/chain descriptors.
- Control and ablation: Run the same model and seeds on random, protein-cold, lipid-cold, and dual-cold splits. Compare identity grouping against chemical clustering. Ensure generated negatives cannot connect a held-out entity back into training through duplicate identities.
- Validation metric: Balanced accuracy, macro-F1, PR-AUC, and calibration for each split; per-family and per-lipid-class coverage; train-to-test maximum chemical similarity and protein sequence similarity.
- Falsification criterion: Reject the claim that the random split is optimistic if cold-split performance and uncertainty are reproducibly equivalent while overlap diagnostics confirm strict entity separation.
- Confounders: Only 35 proteins and 9 domains limit the precision of family-held-out estimates; some cold partitions may lack both verified classes; chemical clustering thresholds can change task difficulty.
- Evidence strength: direct for current split overlap; established methodological support for chemistry-aware splitting; indirect for expected performance reduction.
- Added: 2026-06-07

#### BIO-PROP-20260607-003: Preserve assay context as part of the prediction target

- Status: proposed
- Priority: high
- Project observation: The dataset stores `Screen` as `in vitro` or `in cellulo`, but `PLIDataset.get` trains a single context-free `Interaction` label. The primary study describes different biological and technical capabilities for the two screens and reports that only six LTPs showed lipid mobilization in both assays.
- Biochemical proposal: Preserve assay provenance and evaluate either separate assay-specific tasks or a shared encoder with assay-conditioned prediction heads. Do not interpret a positive in one assay as evidence that the same pair must be positive in the other.
- Mechanism or rationale: In-cellulo association depends on HEK293 metabolism, lipid availability, localization, and active pathways. The in-vitro assay uses recombinant proteins and simplified membranes and may include bacterial preload. These assays measure related but non-identical manifestations of LTP-lipid association.
- Supporting sources: BIO-PAPER-20260607-001; BIO-PAPER-20260607-006
- Required data or audit: Retain assay identity, expression host, purification success, membrane source/composition, lipid detection method, replicate support, and whether a pair was observable in each assay.
- Control and ablation: Compare pooled context-free labels with assay-stratified models and an assay-conditioned multi-task model. Evaluate cross-assay transfer by training on one context and testing only on independently supported pairs from the other.
- Validation metric: Per-assay balanced accuracy, PR-AUC, calibration, and cross-assay concordance; performance stratified by LTP family and lipid class.
- Falsification criterion: Reject assay conditioning if complete source records show equivalent detection opportunity and label semantics across assays, or if repeated-seed conditioned models do not improve either assay-specific validation or calibration.
- Confounders: Assay and protein coverage are not balanced; differences may be driven by expression success or lipid availability rather than intrinsic specificity.
- Evidence strength: direct for assay differences in the primary source; direct for context being discarded by the current model input.
- Added: 2026-06-07

#### BIO-PROP-20260607-004: Encode lipid identity resolution and structural uncertainty

- Status: proposed
- Priority: high
- Project observation: Chemical graphs are generated as definite molecular graphs from available SMILES, while the underlying lipid names have heterogeneous resolution. In the audit, most repeated SMILES tokens with detected chiral centres retain at least one unassigned centre. Coarse `Lipid` and SMILES identifiers can also merge rows that are distinct at `FullIdentityOfLipid`.
- Biochemical proposal: Add an explicit identity-resolution field following LIPID MAPS levels and distinguish observed structure from enumerated candidate structure. For incomplete identities, use a set or distribution of compatible structures, or mask unknown chain position, double-bond position, and stereochemistry instead of presenting one candidate graph as experimentally established.
- Mechanism or rationale: LTP selectivity can depend on headgroup, chain length, unsaturation, sn-position, and stereochemistry. GLTP and STARD10 experiments directly show chain-dependent accommodation or preference. A single over-specified graph can inject unsupported certainty, while collapsing to class alone removes real biochemical determinants.
- Supporting sources: BIO-PAPER-20260607-002; BIO-PAPER-20260607-003; BIO-PAPER-20260607-004; BIO-PAPER-20260607-007
- Required data or audit: Map each `FullIdentityOfLipid` to LIPID MAPS nomenclature and an identity-resolution level; record which chain positions, double-bond positions/configurations, stereocentres, ether/ester linkages, and protonation states are observed versus inferred.
- Control and ablation: Compare current single-graph encoding with (1) uncertainty masks, (2) candidate-structure pooling, and (3) class plus measured chain-composition descriptors. Stratify by identity-resolution level and exclude exact identity duplicates across splits.
- Validation metric: Validation balanced accuracy and calibration by resolution tier; consistency across candidate structures; performance on complete-structure lipids as the least ambiguous subset.
- Falsification criterion: Reject added uncertainty handling if all training identities can be traced to complete experimentally resolved structures, or if repeated-seed ablations show no improvement in calibration or robustness on lower-resolution tiers.
- Confounders: Candidate enumeration may create many chemically plausible but biologically absent isomers; LIPID MAPS mappings may be one-to-many; protonation and membrane state remain assay-dependent.
- Evidence strength: direct for heterogeneous project identifiers and unassigned stereocentres; direct for structural-resolution standards and family-specific chain effects; indirect for the best computational uncertainty representation.
- Added: 2026-06-07
